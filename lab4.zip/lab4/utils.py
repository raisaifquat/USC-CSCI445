
def clamp(value, range_min, range_max):
    return max(min(value, range_max), range_min)